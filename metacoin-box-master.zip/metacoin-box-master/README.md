# MetaCoin Truffle Box

MetaCoin example Truffle project
